import os, sys, time, json, random, websocket, threading, concurrent.futures
import hashlib
import colorama
from datetime import datetime
from colorama import Fore, Style, init
init(autoreset=True)

#[[
    # 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# with open("config.json", "r") as f:
#     config = json.load(f)
# 
# 
# 
# 
# 
# 

#
#   
#   
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 


# Remove KeyAuth and license logic
# Remove the answer() function and its call

TITLE = f"""{Fore.LIGHTMAGENTA_EX}
╔════╗    ╔╗              ╔═══╗    ╔╗              
║╔╗╔╗║    ║║              ║╔═╗║    ║║              
╚╝║║╚╝╔══╗║║╔╗╔══╗╔═╗     ║║ ║║╔═╗ ║║ ╔╗╔═╗ ╔══╗╔═╗
  ║║  ║╔╗║║╚╝╝║╔╗║║╔╗╗    ║║ ║║║╔╗╗║║ ╠╣║╔╗╗║╔╗║║╔╝
 ╔╝╚╗ ║╚╝║║╔╗╗║║═╣║║║║    ║╚═╝║║║║║║╚╗║║║║║║║║═╣║║ 
 ╚══╝ ╚══╝╚╝╚╝╚══╝╚╝╚╝    ╚═══╝╚╝╚╝╚═╝╚╝╚╝╚╝╚══╝╚╝ 
{Style.RESET_ALL}"""

with open("config.json", "r") as f:
    config = json.load(f)

statuses = [config["presence"]["status"]] 
activity_texts = [config["presence"]["activity_text"]]  
activity_types = [config["presence"]["activity_type"]]  
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def log_success(token):
    timestamp = f"{Fore.WHITE}{datetime.now().strftime('%H:%M:%S')}"
    success_label = f"{Fore.LIGHTMAGENTA_EX}SUCCESS"
    token_disp = f"{Fore.LIGHTMAGENTA_EX}{token[:30]}{'*' * 5}"
    print(f"{timestamp} {success_label} {Fore.WHITE}Successfully Onlined Token Token: {token_disp}{Fore.WHITE}")

def format_token(token): return token.split(":")[-1] if ":" in token else token

def online(token):
    token = format_token(token)
    try:
        ws = websocket.WebSocket()
        ws.connect('wss://gateway.discord.gg/?v=6&encoding=json')
        hello = json.loads(ws.recv())
        interval = hello['d']['heartbeat_interval']

        type_name = random.choice(activity_types)
        status_text = random.choice(activity_texts)
        gamejson = {"name": status_text, "type": {"Playing": 0, "Streaming": 1, "Listening": 2, "Watching": 3}.get(type_name, 3)}
        if type_name == "Streaming":
            gamejson["url"] = f"https://twitch.tv/{status_text}"

        auth = {
            "op": 2,
            "d": {
                "token": token,
                "properties": {"$os": sys.platform, "$browser": "RTB", "$device": sys.platform},
                "presence": {"game": gamejson, "status": random.choice(statuses), "since": 1000, "afk": False}
            }
        }

        ws.send(json.dumps(auth))
        log_success(token)

        def heartbeat():
            while True:
                time.sleep(interval / 1000)
                try: ws.send(json.dumps({"op": 1, "d": None}))
                except: break
        threading.Thread(target=heartbeat, daemon=True).start()
        time.sleep(60)
        ws.close()

    except Exception as e:
        print(f"{Fore.RED}{datetime.now().strftime('%H:%M:%S')} ERROR {Fore.WHITE}Token: {token[:30]}***** | {e}")

def load_tokens(paths):
    tokens = []
    for path in paths:
        try:
            with open(path, "r") as f: tokens += [t.strip() for t in f if t.strip()]
        except: pass
    return tokens

if __name__ == "__main__":
    clear_screen()
    print(TITLE)
    tokens = load_tokens(["data/1m_tokens.txt", "data/3m_tokens.txt"])
    print(f"{Fore.WHITE}{datetime.now().strftime('%H:%M:%S')} INFO {Fore.WHITE}Loaded {len(tokens)} tokens.")
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(100, len(tokens))) as ex:
        ex.map(online, tokens)
