import os
import requests
import time
import json
import random
import threading
import hashlib
import colorama
import sys
import base64
import httpx
import tls_client
from concurrent.futures import ThreadPoolExecutor, as_completed
import time, uuid, json
from datetime import datetime
from colorama import init, Fore, Style
# Removed: from keyauth import *
from concurrent.futures import ThreadPoolExecutor, as_completed

init(autoreset=True)


config_path = os.path.join(os.path.dirname(sys.executable if getattr(sys, 'frozen', False) else __file__), "config.json")

with open(config_path, "r") as f:
    config = json.load(f)

# Removed KeyAuth license logic and initialization
# license = config.get("License")
# def getchecksum(): ...
# keyauthapp = api(...)
# if keyauthapp.checkblacklist(): ...
# def answer(): ...
# answer()
# os.system('cls')

# Colors
MAGENTA = Fore.MAGENTA
M = Fore.LIGHTMAGENTA_EX
WHITE = Fore.WHITE
LIGHTYELLOW = Fore.LIGHTYELLOW_EX
RESET = Style.RESET_ALL

# Set console title
os.system("title Boost Tool V4")

ascii_art = f"""{M}
               ╔══╗              ╔╗     ╔════╗        ╔╗ 
               ║╔╗║             ╔╝╚╗    ║╔╗╔╗║        ║║ 
               ║╚╝╚╗╔══╗╔══╗╔══╗╚╗╔╝    ╚╝║║╚╝╔══╗╔══╗║║ 
               ║╔═╗║║╔╗║║╔╗║║══╣ ║║       ║║  ║╔╗║║╔╗║║║ 
               ║╚═╝║║╚╝║║╚╝║╠══║ ║╚╗     ╔╝╚╗ ║╚╝║║╚╝║║╚╗
               ╚═══╝╚══╝╚══╝╚══╝ ╚═╝     ╚══╝ ╚══╝╚══╝╚═╝
"""

captcha_service = "Captcha Free"
onliner_status = "Enabled"

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

print(ascii_art)
# Removed License Expiry line
# print(f"{M}License Expiry:{RESET} 00:00:00")
print(f"{M}Captcha Service:{RESET} {captcha_service}")
print(f"{M}Onliner:{RESET} {onliner_status}\n")

print(f"{M}1{RESET} | Boost Server")
print(f"{M}2{RESET} | Token Checker")
print(f"{M}3{RESET} | Stock\n")

def timestamp():
    return datetime.now().strftime("%H:%M:%S")

def load_tokens(file_path):
    try:
        with open(file_path, "r") as f:
            tokens = [line.strip() for line in f if line.strip()]
        return tokens
    except FileNotFoundError:
        print(f"{timestamp()} | ERROR | Token file {file_path} not found.")
        return []

user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)"
    " Chrome/114.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)"
    " Version/14.0 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko)"
    " Chrome/91.0.4472.114 Safari/537.36",
]

def extract_token(full_line):
    """
    Extract the token from line.
    Supports raw token or Email:password:token format.
    """
    parts = full_line.split(":")
    if len(parts) >= 3:
        # token is last segment
        return parts[-1]
    return full_line

def is_token_valid(token, ua_index):
    url = "https://discord.com/api/v9/users/@me"
    headers = {
        "Authorization": token,
        "User-Agent": user_agents[ua_index % len(user_agents)],
    }
    try:
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code == 200:
            return True, token
        else:
            return False, token
    except requests.RequestException:
        return False, token

def token_checker():
    duration = input(f"{M}INPUT{RESET} | Duration of Boosts (1 or 3): ").strip()
    if duration not in ["1", "3"]:
        print(f"{M}INPUT{RESET} | Invalid duration. Please enter 1 or 3.")
        return

    token_file = f"data/{duration}m_tokens.txt"
    tokens = load_tokens(token_file)
    if not tokens:
        print(f"{M}INFO{RESET} | No tokens loaded.")
        return

    clear_screen()
    print(ascii_art)


    valid_count = 0
    invalid_count = 0

    with ThreadPoolExecutor(max_workers=30) as executor:
        futures = []
        for i, line in enumerate(tokens):
            token = extract_token(line)
            futures.append(executor.submit(is_token_valid, token, i))

        for future in as_completed(futures):
            valid, token = future.result()
            if valid:
                valid_count += 1
                print(f"{WHITE}{timestamp()} {WHITE}| {M}SUCCESS {WHITE}|{RESET} Valid Token [Token: {M}{token[:30]}{RESET}]")
            else:
                invalid_count += 1

    print(f"{WHITE}{timestamp()} {WHITE}| {LIGHTYELLOW}INFO {Fore.WHITE}|{RESET} Finished Checking Tokens [Valid: {valid_count} | Invalid: {invalid_count}]")
    input(f"{WHITE}{timestamp()} {WHITE}| {LIGHTYELLOW}INFO {Fore.WHITE}|{RESET} Press Enter To go to menu: ").strip().lower()
    main_menu()

SUCCESS_DIR = "success_orders"  # make sure this nigga ass dir exists

def log(message, level="INFO", token=None):
    timestamp = datetime.now().strftime("%H:%M:%S")
    level_colors = {
        "INFO": Fore.YELLOW,
        "SUCCESS": Fore.MAGENTA,
        "WARN": Fore.RED
    }
    level_color = level_colors.get(level.upper(), Fore.WHITE)
    
    token_display = f"[Token: {Fore.MAGENTA}{token[:30]}*****{Style.RESET_ALL}]" if token else ""
    
    print(f"{Fore.LIGHTBLACK_EX}{timestamp}{Style.RESET_ALL} | {level_color}{level.upper()}{Style.RESET_ALL} | {message} {token_display}")

def log(prefix, color, message):
    print(f"{color}{timestamp()} {prefix} {Style.RESET_ALL}{message}")

class Booster:
    def __init__(self):
        self.proxy = self.get_proxy()
        self.chrome_version = f"Chrome_{random.randint(110, 118)}"
        self.client = tls_client.Session(
            client_identifier=self.chrome_version,
            random_tls_extension_order=True,
            ja3_string='771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,18-23-45-11-27-10-0-5-13-65037-16-51-17513-43-35-65281-41,25497-29-23-24,0'
        )
        self.locale = "en-US"
        self.user_agent = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) {self.chrome_version}.0.0.0 Safari/537.36"
        self.x_properties = self.get_x_properties()
        self.fingerprint, self.cookies = self.get_fingerprint()
        self.failed = []
        self.success = []
        self.lock = threading.Lock()

    def get_proxy(self):
        try:
            with open("assets/proxies.txt", "r") as f:
                proxies = f.read().splitlines()
                choice = random.choice(proxies)
                return {"http": f"http://{choice}", "https": f"http://{choice}"}
        except Exception:
            return None

    def get_x_properties(self):
        props = {
            "os": "Windows",
            "browser": "Chrome",
            "device": "",
            "system_locale": self.locale,
            "browser_user_agent": self.user_agent,
            "browser_version": f"{self.chrome_version}.0.0.0",
            "os_version": "10",
            "referrer": "",
            "referring_domain": "",
            "referrer_current": "",
            "referring_domain_current": "",
            "release_channel": "stable",
            "client_build_number": 236850,
            "client_event_source": None
        }
        return base64.b64encode(json.dumps(props, separators=(',', ':')).encode()).decode()

    def get_fingerprint(self):
        headers = {
            "authority": "discord.com",
            "method": "GET",
            "path": "/api/v9/experiments",
            "scheme": "https",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "max-age=0",
            "Priority": "u=0, i",
            "Sec-Ch-Ua": '"Not/A)Brand;v=8", "Chromium;v=126", "Brave;v=126"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": "Windows",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Sec-Gpc": "1",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": self.user_agent
        }
        try:
            r = httpx.get("https://discord.com/api/v9/experiments", headers=headers, timeout=5)
            if r.status_code == 200:
                fingerprint = r.json().get("fingerprint")
                cookies = f'locale=en-US; __dcfduid={r.cookies.get("__dcfduid")}; __sdcfduid={r.cookies.get("__sdcfduid")}; __cfruid={r.cookies.get("__cfruid")}; _cfuvid={r.cookies.get("_cfuvid")}'
                return fingerprint, cookies
        except Exception as e:
            log("ERROR", Fore.RED, f"Error getting fingerprint: {e}")
        return None, None

    def boost(self, token, invite, guild_id, watermark=False):
        headers = {
            "authority": "discord.com",
            "scheme": "https",
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Authorization": token,
            "Content-Type": "application/json",
            "Cookie": self.cookies,
            "Origin": "https://discord.com",
            "Priority": "u=1, i",
            "Referer": "https://discord.com/channels/@me",
            "Sec-Ch-Ua": '"Not/A)Brand;v=8", "Chromium;v=126", "Brave;v=126"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": "Windows",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Gpc": "1",
            "User-Agent": self.user_agent,
            "X-Debug-Options": "bugReporterEnabled",
            "X-Discord-Locale": "en-US",
            "X-Discord-Timezone": "Asia/Calcutta",
            "X-fingerprint": self.fingerprint,
            "X-Super-Properties": self.x_properties
        }
        
        # checks the boost slots
        try:
            slots = self.client.get("https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots", headers=headers)
            if slots.status_code != 200:
                with self.lock:
                    log("ERROR", Fore.RED, f"Invalid token or no nitro: {token[:30]}...")
                    self.failed.append(token)
                return False
            slot_json = slots.json()
            if not slot_json:
                with self.lock:
                    log("ERROR", Fore.RED, f"No boost slots available: {token[:30]}...")
                    self.failed.append(token)
                return False

            # joins the server
            join_response = self.client.post(f"https://discord.com/api/v9/invites/{invite}", headers=headers, json={})
            if join_response.status_code != 200:
                with self.lock:
                    log("ERROR", Fore.RED, f"Failed to join server: {M}{token[:30]}{Fore.RESET}... [Invite: {invite}]")
                    self.failed.append(token)
                return False

            with self.lock:
                print(f"{WHITE}{timestamp()} {WHITE}| {M}SUCCESS {WHITE}|{RESET} Succesfully Joined Server, [Token: {M}{token[:30]}*****{RESET}]")

            boosts_list = [boost["id"] for boost in slot_json]
            payload = {"user_premium_guild_subscription_slot_ids": boosts_list}

            headers["method"] = "PUT"
            headers["path"] = f"/api/v9/guilds/{guild_id}/premium/subscriptions"

            boosted = self.client.put(f"https://discord.com/api/v9/guilds/{guild_id}/premium/subscriptions", json=payload, headers=headers)
            if boosted.status_code == 201:
                with self.lock:
                    print(f"{WHITE}{timestamp()} {WHITE}| {M}SUCCESS {WHITE}|{RESET} Succesfully Boosted Server, [Token: {M}{token[:30]}*****{RESET}]")
                    self.success.append(token)

                    
                    if watermark:
                        self.watermark_token(token, guild_id)

                    return True

            else:
                with self.lock:
                    log("ERROR", Fore.RED, f"Failed to boost: {M}{token[:30]}{Fore.RESET}*** [{invite}]")
                    self.failed.append(token)
                return False
            

        except Exception as e:
            with self.lock:
                log("ERROR", Fore.RED, f"Exception during boost: {e} [Token: {M}{token[:30]}{Fore.RESET}***]")
                self.failed.append(token)
            return False
        
    
        
    def watermark_token(self, token, guild_id=None):
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
            "User-Agent": self.user_agent
        } 

        session = httpx.Client()

        # Use bio from config, fallback if missing
        bio = config.get("bio", "**DONT KICK ME** Boosted by .gg/dcstore")
        try:
            session.patch("https://discord.com/api/v9/users/@me/profile", headers=headers, json={"bio": bio})
        except Exception as e:
            log("WARN", Fore.YELLOW, f"Failed to update bio: {e} [Token: {token[:30]}...]")

        # Avatar
        avatar_data = get_random_image_b64("data/avatar")
        if avatar_data:
            try:
                session.patch("https://discord.com/api/v9/users/@me", headers=headers, json={"avatar": avatar_data})
            except Exception as e:
                log("WARN", Fore.YELLOW, f"Failed to update avatar: {e} [Token: {token[:30]}...]")

        # Banner
        banner_data = get_random_image_b64("data/banner")
        if banner_data:
            try:
                session.patch("https://discord.com/api/v9/users/@me/profile", headers=headers, json={"banner": banner_data})
            except Exception as e:
                log("WARN", Fore.YELLOW, f"Failed to update banner: {e} [Token: {token[:30]}...]")

        # Nickname from config if guild_id provided
        if guild_id:
            nickname = config.get("nickname", "! CHECK BIO")
            try:
                session.patch(
                    f"https://discord.com/api/v9/guilds/{guild_id}/members/@me",
                    headers=headers,
                    json={"nick": nickname}
                )
            except Exception as e:
                log("WARN", Fore.YELLOW, f"Failed to update nickname: {e} [Token: {token[:30]}...]")

        print(f"{WHITE}{timestamp()} {WHITE}| {M}SUCCESS {WHITE}|{RESET} Watermarked Token [Avatar, Banner, Bio, Nickname] [Token: {M}{token[:30]}*****{RESET}]")


def image_to_b64(image_path):
    import base64, os
    if not os.path.exists(image_path):
        return None
    ext = os.path.splitext(image_path)[1].lower().replace('.', '')
    mime = {'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'gif': 'image/gif'}.get(ext, 'image/png')
    with open(image_path, 'rb') as f:
        return f"data:{mime};base64,{base64.b64encode(f.read()).decode('utf-8')}"

def get_random_image_b64(directory):
    import random, os
    files = [f for f in os.listdir(directory) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif'))]
    if not files:
        return None
    return image_to_b64(os.path.join(directory, random.choice(files)))


def get_invite_code(invite):
    if "discord.gg/" in invite:
        return invite.split("discord.gg/")[1].split("/")[0]
    if "discord.com/invite/" in invite:
        return invite.split("discord.com/invite/")[1].split("/")[0]
    return invite

def check_invite(invite):
    try:
        response = httpx.get(f"https://discord.com/api/v9/invites/{invite}?inputValue={invite}&with_counts=true&with_expiration=true", timeout=5)
        data = response.json()
        if "guild" in data:
            return data["guild"]["id"]
        return False
    except Exception:
        return False

def boost_server():
    invite = input(f"{M}INPUT {WHITE}│ {Style.RESET_ALL}Enter Discord Server Invite: ").strip()
    invite_code = get_invite_code(invite)
    guild_id = check_invite(invite_code)
    if not guild_id:
        log("ERROR", Fore.RED, "Invalid invite!")
        time.sleep(2)
        return

    stock_type = input(f"{M}INPUT {WHITE}│ {Style.RESET_ALL}Enter the Boost Type 1m or 3m: ").strip()
    if stock_type not in ("1m", "3m"):
        log("ERROR", Fore.RED, "Invalid stock type!")
        return
    available_boosts = len([line for line in open(f"data/{stock_type}_tokens.txt") if line.strip()]) * 2


    num_boosts = input(f"{M}INPUT {WHITE}│ {Style.RESET_ALL}Number of boosts ({available_boosts} Available): ").strip()
    if not num_boosts.isdigit() or int(num_boosts) <= 0:
        log("ERROR", Fore.RED, "Invalid number of boosts!")
        return
    num_boosts = int(num_boosts)

    watermark = input(f"{M}INPUT {WHITE}│ {Style.RESET_ALL}Watermark tokens? (y/n): ").strip().lower() == "y"

    clear_screen()
    print(ascii_art)

    filename = f"data/{stock_type}_tokens.txt"
    try:
        with open(filename, "r") as f:
            raw_lines = [line.strip() for line in f if line.strip()]
    except Exception:
        log("ERROR", Fore.RED, f"Failed to load tokens from {filename}")
        return

    tokens = [extract_token(line) for line in raw_lines]
    required_tokens = (num_boosts + 1) // 2  
    tokens = tokens[:required_tokens]

    if len(tokens) < required_tokens:
        log("WARN", Fore.YELLOW, f"Not enough tokens. Needed {required_tokens}, found {len(tokens)}.")
        return

    booster = Booster()
    print(f"{WHITE}{timestamp()} {WHITE}| {M}SUCCESS {WHITE}|{RESET} Starting to boost {invite_code} using {num_boosts} boosts")

    count = 0
    with ThreadPoolExecutor(max_workers=min(50, required_tokens)) as executor:
        futures = []
        for token in tokens:
            if count >= num_boosts:
                break
            futures.append(executor.submit(booster.boost, token, invite_code, guild_id, watermark))
            count += 2  

        for f in as_completed(futures):
            pass

    print(f"{WHITE}{timestamp()} {WHITE}| {LIGHTYELLOW}INFO {Fore.WHITE}|{RESET} Finished Boosting Server {invite_code} — Boosts used: {min(num_boosts, count)}, Failures: {len(booster.failed)}")
    input(f"\n{M}Press ENTER to return to the menu...")
    main_menu()



def stock_check():
    one_month_path = "data/1m_tokens.txt"
    three_month_path = "data/3m_tokens.txt"

    def count_tokens(path):
        if not os.path.exists(path):
            return 0
        with open(path, "r", encoding="utf-8") as f:
            tokens = [line.strip() for line in f if line.strip()]
        return len(tokens)

    one_m = count_tokens(one_month_path)
    three_m = count_tokens(three_month_path)

    one_m_boosts = one_m * 2
    three_m_boosts = three_m * 2

    clear_screen()
    print(ascii_art)
    print(f"{M}[/] Stock Overview")
    print(f"{M}────────────────────────────")

    print(f"{M}[/] {Fore.LIGHTBLACK_EX}1 Month Tokens: {Style.RESET_ALL}{one_m}")
    print(f"{M}[/] {Fore.LIGHTBLACK_EX}1 Month Boosts: {Style.RESET_ALL}{one_m_boosts}\n")

    print(f"{M}[/] {Fore.LIGHTBLACK_EX}3 Month Tokens: {Style.RESET_ALL}{three_m}")
    print(f"{M}[/] {Fore.LIGHTBLACK_EX}3 Month Boosts: {Style.RESET_ALL}{three_m_boosts}")

    print(f"{Fore.LIGHTBLACK_EX}────────────────────────────")
    input(f"\n{M}Press ENTER to return to the menu...")
    main_menu()


def main_menu():
    clear_screen()
    print(ascii_art)
    # Removed License Expiry line
    # print(f"{M}License Expiry:{RESET} 00:00:00")
    print(f"{M}Captcha Service:{RESET} {captcha_service}")
    print(f"{M}Onliner:{RESET} {onliner_status}\n")

    print(f"{M}1{RESET} | Boost Server")
    print(f"{M}2{RESET} | Token Checker")
    print(f"{M}3{RESET} | Stock\n")

    option = input(f"{M}INPUT{RESET} | Select A Option: ").strip()

    if option == "1":
        boost_server()
        input(f"{WHITE}{timestamp()} {WHITE}| {LIGHTYELLOW}INFO {Fore.WHITE}|{RESET} Press Enter to return to menu.")
        main_menu()

    elif option == "2":
        token_checker()
        input(f"{WHITE}{timestamp()} {WHITE}| {LIGHTYELLOW}INFO {Fore.WHITE}|{RESET} Press Enter to return to menu.")
        main_menu()

    elif option == "3":
        stock_check()
        input(f"{WHITE}{timestamp()} {WHITE}| {LIGHTYELLOW}INFO {Fore.WHITE}|{RESET} Press Enter to return to menu.")
        main_menu()

    else:
        print(f"{M}INPUT{RESET} | Invalid option selected. Please try again.")
        time.sleep(1.5)
        main_menu()

# Call it at the start
main_menu()
if __name__ == "__main__":
    main_menu()